function allowDrop(ev) {
  ev.preventDefault();
}
function drag(ev) {
  ev.dataTransfer.setData("text", ev.target.id);
}
function drop(ev) {
  ev.preventDefault();
  const data = ev.dataTransfer.getData("text");
  if (data === "key") {
    document.getElementById("feedback").innerText = "🔓 Door unlocked! You escaped!";
  } else {
    document.getElementById("feedback").innerText = "❌ Wrong item! Try again.";
  }
}