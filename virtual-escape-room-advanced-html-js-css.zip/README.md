# 🧠 Advanced Virtual Escape Room (HTML/JS/CSS + Drag & Drop)

A more interactive version of the virtual escape room with drag-and-drop puzzles and image clues.

## Features
- Drag & drop image puzzles
- Puzzle answer validation
- Simple browser-based experience

## How to Use
1. Unzip the folder
2. Open `index.html` in your browser

Enjoy solving the puzzles!
