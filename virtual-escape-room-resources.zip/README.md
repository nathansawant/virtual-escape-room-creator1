# 🧩 Virtual Escape Room Creator

A web-based app to create and play custom escape rooms.

## Features
- Admins create rooms with puzzle stages
- Players solve puzzles stage by stage
- Role-based access and game progression

## Tech Stack
- Frontend: React + Tailwind CSS
- Backend: Node.js + Express
- Database: MongoDB (Mongoose)

## Setup Instructions
1. Clone the repo
2. Fill out `.env` using `.env.example`
3. Run backend: `npm install && npm start`
4. Run frontend: `npm install && npm start`
