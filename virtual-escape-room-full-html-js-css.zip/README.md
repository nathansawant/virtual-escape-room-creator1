# 🧩 Virtual Escape Room Creator (HTML/JS/CSS Version)

This is a simplified version of the virtual escape room using plain HTML, JavaScript, and CSS (no frameworks).

## Features
- Admin page to create rooms and puzzles
- Player page to solve escape room challenges

## How to Run
Just open `index.html` in your browser.

---
No backend or database is required in this version.
