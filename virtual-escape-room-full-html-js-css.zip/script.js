let puzzles = [];
let current = 0;

function addPuzzle() {
  const question = document.getElementById("question").value;
  const answer = document.getElementById("answer").value.toLowerCase();
  if (question && answer) {
    puzzles.push({ question, answer });
    alert("Puzzle added!");
    document.getElementById("question").value = "";
    document.getElementById("answer").value = "";
  }
}

function startGame() {
  current = 0;
  if (puzzles.length === 0) {
    alert("Please add some puzzles first.");
    return;
  }
  showPuzzle();
}

function showPuzzle() {
  const puzzle = puzzles[current];
  document.getElementById("currentPuzzle").innerText = puzzle ? puzzle.question : "No more puzzles.";
  document.getElementById("feedback").innerText = "";
  document.getElementById("userAnswer").value = "";
}

function checkAnswer() {
  const userInput = document.getElementById("userAnswer").value.toLowerCase();
  if (userInput === puzzles[current].answer) {
    current++;
    if (current >= puzzles.length) {
      document.getElementById("feedback").innerText = "🎉 You escaped!";
      document.getElementById("currentPuzzle").innerText = "";
    } else {
      document.getElementById("feedback").innerText = "✅ Correct! Next puzzle...";
      showPuzzle();
    }
  } else {
    document.getElementById("feedback").innerText = "❌ Wrong answer. Try again.";
  }
}